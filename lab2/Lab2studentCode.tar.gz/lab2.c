/*Implementation of these functions go in this file*/
circle* read_data(FILE* input, int* num)
{

}

void calc_centroid(FILE* output, circle* circles, int num)
{

}
