/*
  Main should:
  1. Open a file for reading, the input file from command line args 
     check to make sure the correct number of argurments were on the command line
  2. Open a file for writing, the output file from command line args
     Make sure the files open appropriately
     Make sure you close the files when they are no longer needed
  3. Declare an int to send to read_data
  4. Call read_data
  5. Call calc_centroid
  6. return 0
     Make sure you release the dynamically allocated memory when it is no longer needed
*/
int main(int argc, char const *argv[])
{

  return 0;
}
